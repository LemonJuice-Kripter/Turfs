fx_version("cerulean")

game("gta5")

author("Lemon")

lua54("TC168")

version("ultima")

ui_page("nui/index.html")

description("Daca mai trebuie sa fac un sistem de turf-uri vreodata in viata mea, o sa ma impusc in creier!")

client_scripts({"@vrp/client/Proxy.lua", "@vrp/client/Tunnel.lua", "client.lua"})

server_scripts({"@vrp/lib/utils.lua", "config.lua", "server.lua"})

files({"nui/*", "nui/img/*.webp"})

file("stream/*.gfx")
