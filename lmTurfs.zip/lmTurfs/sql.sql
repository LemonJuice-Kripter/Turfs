CREATE TABLE `lemon_taxe` (
  `turfId` int(5) NOT NULL,
  `buyerName` varchar(50) NOT NULL,
  `buyer` int(5) NOT NULL,
  `mafiotName` varchar(30) NOT NULL,
  `mafiot` int(6) NOT NULL,
  `turfName` varchar(50) NOT NULL,
  `tax` int(5) NOT NULL,
  `time` varchar(60) DEFAULT NULL,
  `idTaxa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `lemon_turfs` (
  `turfId` int(11) NOT NULL,
  `ownerFaction` varchar(50) NOT NULL DEFAULT 'none',
  `x` float DEFAULT NULL,
  `y` float DEFAULT NULL,
  `z` float DEFAULT NULL,
  `radius` float DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `pretTaxa` int(11) NOT NULL DEFAULT 1,
  `taxaTurf` text DEFAULT NULL,
  `time` varchar(30) NOT NULL DEFAULT 'Necunoscut'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `lemon_wars` (
  `attacker` varchar(150) NOT NULL,
  `defender` varchar(150) NOT NULL,
  `data` varchar(5000) NOT NULL,
  `warId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `lemon_taxe`
  ADD PRIMARY KEY (`idTaxa`);

ALTER TABLE `lemon_turfs`
  ADD PRIMARY KEY (`turfId`);


ALTER TABLE `lemon_wars`
  ADD PRIMARY KEY (`warId`);

ALTER TABLE `lemon_taxe`
  MODIFY `idTaxa` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `lemon_turfs`
  MODIFY `turfId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;


ALTER TABLE `lemon_wars`
  MODIFY `warId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;